//
//  TabBarVC.h
//  XSchoolParents
//
//  Created by 李秋 on 2017/10/12.
//  Copyright © 2017年 李秋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarVC : UITabBarController

@end
