//
//  TabBarVC.m
//  XSchoolParents
//
//  Created by 李秋 on 2017/10/12.
//  Copyright © 2017年 李秋. All rights reserved.
//

#import "TabBarVC.h"
#import "LQMessageVC.h"
#import "LQContactVC.h"
#import "LQMoreVC.h"
@interface TabBarVC ()
@property (nonatomic,assign) NSInteger index;
@end

@implementation TabBarVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createTabBar];
}

- (void)createTabBar{
     [self createControllerWithTitle:@"消息" image:@"menu-message-normal"selectedimage:@"menu-message-down" className:[LQMessageVC class]];
     [self createControllerWithTitle:@"联系人" image:@"menu-contact-normal"selectedimage:@"menu-contact-down" className:[LQContactVC class]];
     [self createControllerWithTitle:@"更多" image:@"menu-more-normal"selectedimage:@"menu-more-down" className:[LQMoreVC class]];
    
}

//提取公共方法
- (void)createControllerWithTitle:(NSString *)title image:(NSString *)image selectedimage:(NSString *)selectedimage  className:(Class)class{
    UIViewController *vc = [[class alloc]init];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:vc];
    nav.tabBarItem.title = title;
    nav.tabBarItem.image = [[UIImage imageNamed:image] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nav.tabBarItem.selectedImage = [[UIImage imageNamed:selectedimage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [self addChildViewController:nav];
    nav.tabBarController.tabBar.backgroundColor = [UIColor whiteColor];
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithRed:18.0/255 green:183.0/255 blue:245.0/255 alpha:1.0], NSForegroundColorAttributeName,
                                                       nil,nil] forState:UIControlStateSelected];
}

// 点击tabbarItem自动调用
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSInteger index = [self.tabBar.items indexOfObject:item];
    
    if (index != _index) {
       [self animationWithIndex:index];
        _index = index;
    }
   
    
    if([item.title isEqualToString:@"发现"])
    {
        // 也可以判断标题,然后做自己想做的事
    }
    
}
- (void)animationWithIndex:(NSInteger) index {
    NSMutableArray * tabbarbuttonArray = [NSMutableArray array];
    for (UIView *tabBarButton in self.tabBar.subviews) {
        if ([tabBarButton isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            [tabbarbuttonArray addObject:tabBarButton];
        }
    }
    /**
     CABasicAnimation类的使用方式就是基本的关键帧动画。
     
     所谓关键帧动画，就是将Layer的属性作为KeyPath来注册，指定动画的起始帧和结束帧，然后自动计算和实现中间的过渡动画的一种动画方式。
     */
    CABasicAnimation*pulse = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    
    pulse.timingFunction= [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    pulse.duration = 0.2;
    pulse.repeatCount= 1;
    pulse.autoreverses= YES;
    pulse.fromValue= [NSNumber numberWithFloat:0.7];
    pulse.toValue= [NSNumber numberWithFloat:1.3];
    [[tabbarbuttonArray[index] layer]
     addAnimation:pulse forKey:nil];
    
}

@end
